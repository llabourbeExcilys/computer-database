package com.excilys.cdb.back.exception;

public class ComputerDtoNotMatchingException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public ComputerDtoNotMatchingException(String message) {
		super(message);
	}

}
