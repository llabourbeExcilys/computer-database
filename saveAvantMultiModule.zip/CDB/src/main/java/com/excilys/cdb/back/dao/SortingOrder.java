package com.excilys.cdb.back.dao;

public enum SortingOrder {
	ASC,
	DESC;
}
