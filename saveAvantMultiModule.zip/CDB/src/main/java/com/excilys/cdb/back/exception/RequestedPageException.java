package com.excilys.cdb.back.exception;

public class RequestedPageException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public RequestedPageException(String message) {
		super(message);
	}
	

}
